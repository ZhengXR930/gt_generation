.obj/libregexp.fuzz.o: libregexp.c cutils.h libregexp.h libunicode.h \
  libregexp-opcode.h
