.obj/quickjs-libc.fuzz.o: quickjs-libc.c cutils.h list.h quickjs-libc.h \
  quickjs.h
