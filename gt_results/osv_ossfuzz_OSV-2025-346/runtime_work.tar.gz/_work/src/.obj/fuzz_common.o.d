.obj/fuzz_common.o: fuzz/fuzz_common.c fuzz/fuzz_common.h quickjs.h \
  quickjs-libc.h
