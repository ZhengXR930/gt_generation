#!/usr/bin/env bash
set -euo pipefail

export SRC="${SRC:-/gt/_work}"
export OUT="${OUT:-/gt/_out}"
export WORK="${WORK:-/gt/_work}"
export PATH="${HOME:-/tmp}/.cargo/bin:$PATH"
export PIP_BREAK_SYSTEM_PACKAGES="${PIP_BREAK_SYSTEM_PACKAGES:-1}"
mkdir -p "$SRC" "$OUT" "$WORK"

# Recreate the official OSS-Fuzz /src layout from prepared local material.
if [[ ! -e "$SRC/quickjs" && -d /gt/_work/src ]]; then
  ln -s /gt/_work/src "$SRC/quickjs"
fi
if [[ -d /gt/oss_fuzz_src ]]; then
  cp -a -n /gt/oss_fuzz_src/. "$SRC"/
fi
mkdir -p /gt/_work/quickjs 2>/dev/null || true

# Make official dependency scripts retry-safe in the persistent /gt/_work.
_gt_real_git() { command git "$@"; }
git() {
  if [[ "${1:-}" == "clone" ]]; then
    local _gt_url="" _gt_dest="" _gt_i
    local _gt_args=("$@")
    for ((_gt_i=1; _gt_i<${#_gt_args[@]}; _gt_i++)); do
      case "${_gt_args[$_gt_i]}" in
        --branch|--depth|--filter|--origin|--reference|--template|--upload-pack|--config|--separate-git-dir|--jobs)
          ((_gt_i++)) || true
          ;;
        http://*|https://*|git@*|*.git)
          _gt_url="${_gt_args[$_gt_i]}"
          if (( _gt_i + 1 < ${#_gt_args[@]} )) && [[ "${_gt_args[$((_gt_i+1))]}" != -* ]]; then
            _gt_dest="${_gt_args[$((_gt_i+1))]}"
          fi
          ;;
      esac
    done
    if [[ -z "$_gt_dest" && -n "$_gt_url" ]]; then
      _gt_dest="${_gt_url##*/}"
      _gt_dest="${_gt_dest%.git}"
    fi
    if [[ -n "$_gt_dest" ]]; then
      case "$_gt_dest" in
        "$SRC/quickjs"|"$SRC/quickjs/"*) ;;
        /gt/_work/*|"$SRC"/*|"$WORK"/*) rm -rf "$_gt_dest" ;;
      esac
    fi
  fi
  _gt_real_git "$@"
}
export -f git _gt_real_git

# Dockerfile ENV instructions required by the official build.
# No Dockerfile ENV instructions.

# Dockerfile COPY/ADD instructions for project-local helper scripts.
if [[ -e /gt/oss_fuzz_project/build.sh ]]; then mkdir -p /gt/_work; cp -a /gt/oss_fuzz_project/build.sh /gt/_work/; fi
if [[ -e /gt/oss_fuzz_project/run_tests.sh ]]; then mkdir -p /gt/_work; cp -a /gt/oss_fuzz_project/run_tests.sh /gt/_work/; fi
if [[ -e /gt/oss_fuzz_project/run_tests_patch.diff ]]; then mkdir -p /gt/_work; cp -a /gt/oss_fuzz_project/run_tests_patch.diff /gt/_work/; fi

# Official non-clone RUN commands from projects/quickjs/Dockerfile.
git apply $SRC/run_tests_patch.diff
