#!/usr/bin/env bash
set -euo pipefail

export SRC="${SRC:-/gt/_work}"
export OUT="${OUT:-/gt/_out}"
export WORK="${WORK:-/gt/_work}"
export PATH="${HOME:-/tmp}/.cargo/bin:$PATH"
export PIP_BREAK_SYSTEM_PACKAGES="${PIP_BREAK_SYSTEM_PACKAGES:-1}"
export CC="${CC:-clang}"
export CXX="${CXX:-clang++}"
export CFLAGS="${CFLAGS:--O1 -fno-omit-frame-pointer -gline-tables-only -fsanitize=address}"
export CXXFLAGS="${CXXFLAGS:--O1 -fno-omit-frame-pointer -gline-tables-only -fsanitize=address}"
export SANITIZER="${SANITIZER:-address}"
export FUZZING_ENGINE="${FUZZING_ENGINE:-libfuzzer}"
export ARCHITECTURE="${ARCHITECTURE:-x86_64}"
export LIB_FUZZING_ENGINE="${LIB_FUZZING_ENGINE:--fsanitize=fuzzer}"
export FUZZER_LIB="${FUZZER_LIB:-$LIB_FUZZING_ENGINE}"

if [[ ! -e /usr/lib/libFuzzingEngine.a ]]; then
  _gt_fuzzer_lib="$(find /usr/lib /usr/local/lib -path "*/lib/clang/*/lib/linux/libclang_rt.fuzzer_no_main-x86_64.a" -print -quit 2>/dev/null || true)"
  if [[ -n "$_gt_fuzzer_lib" ]]; then ln -sf "$_gt_fuzzer_lib" /usr/lib/libFuzzingEngine.a 2>/dev/null || true; fi
  unset _gt_fuzzer_lib
fi
if ! ldconfig -p 2>/dev/null | grep -q "libc++\.so" && [[ ! -e /usr/lib/x86_64-linux-gnu/libc++.so ]]; then
  _gt_stdlib="$(ldconfig -p 2>/dev/null | awk '/libstdc\+\+\.so/{print $NF; exit}')"
  if [[ -n "$_gt_stdlib" ]]; then ln -sf "$_gt_stdlib" /usr/lib/x86_64-linux-gnu/libc++.so 2>/dev/null || true; fi
  unset _gt_stdlib
fi

# Recreate the official OSS-Fuzz /src layout from prepared local material.
mkdir -p "$SRC" "$OUT" "$WORK"
if [[ -d /gt/_work/src ]]; then
  if [[ ! -e "$SRC/md4c" ]]; then ln -s /gt/_work/src "$SRC/md4c"; fi
  if [[ ! -e /gt/_work/md4c ]]; then ln -s /gt/_work/src /gt/_work/md4c; fi
fi
if [[ ! -e /gt/_work/md4c && -d /gt/_work/src ]]; then
  ln -s /gt/_work/src /gt/_work/md4c
fi
if [[ -d /gt/oss_fuzz_src ]]; then
  cp -a -n /gt/oss_fuzz_src/. "$SRC"/
fi

# Make official dependency scripts retry-safe in the persistent /gt/_work.
_gt_real_git() { command git "$@"; }
git() {
  if [[ "${1:-}" == "clone" ]]; then
    local _gt_url="" _gt_dest="" _gt_i
    local _gt_args=("$@")
    for ((_gt_i=1; _gt_i<${#_gt_args[@]}; _gt_i++)); do
      case "${_gt_args[$_gt_i]}" in
        --branch|--depth|--filter|--origin|--reference|--template|--upload-pack|--config|--separate-git-dir|--jobs)
          ((_gt_i++)) || true
          ;;
        http://*|https://*|git@*|*.git)
          _gt_url="${_gt_args[$_gt_i]}"
          if (( _gt_i + 1 < ${#_gt_args[@]} )) && [[ "${_gt_args[$((_gt_i+1))]}" != -* ]]; then
            _gt_dest="${_gt_args[$((_gt_i+1))]}"
          fi
          ;;
      esac
    done
    if [[ -z "$_gt_dest" && -n "$_gt_url" ]]; then
      _gt_dest="${_gt_url##*/}"
      _gt_dest="${_gt_dest%.git}"
    fi
    if [[ -n "$_gt_dest" ]]; then
      local _gt_dest_path="$_gt_dest"
      [[ "$_gt_dest_path" = /* ]] || _gt_dest_path="$PWD/$_gt_dest_path"
      if [[ -e "$_gt_dest_path" ]] && [[ -n "$(find "$_gt_dest_path" -mindepth 1 -print -quit 2>/dev/null)" ]]; then
        echo "Using staged dependency at $_gt_dest_path instead of cloning $_gt_url" >&2
        return 0
      fi
    fi
  fi
  _gt_real_git "$@"
}
export -f git _gt_real_git

# Dockerfile ENV instructions required by the official build.
# No Dockerfile ENV instructions.

# Dockerfile COPY/ADD instructions for project-local helper scripts.
if [[ -e /gt/oss_fuzz_project/run_tests.sh ]]; then mkdir -p /gt/_work; cp -a /gt/oss_fuzz_project/run_tests.sh /gt/_work/; fi
if [[ -e /gt/oss_fuzz_project/build.sh ]]; then mkdir -p /gt/_work; cp -a /gt/oss_fuzz_project/build.sh /gt/_work/; fi

# Official non-clone RUN commands from projects/md4c/Dockerfile.
cd "$SRC"
git clone --depth 1 https://github.com/google/fuzzing && mv fuzzing/dictionaries/markdown.dict $SRC/fuzz-mdhtml.dict && rm -rf fuzzing
zip -j $SRC/fuzz-mdhtml_seed_corpus.zip $SRC/md4c/test/fuzzers/seed-corpus/*
